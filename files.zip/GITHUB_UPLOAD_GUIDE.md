# Putting this on GitHub

## Option A — GitHub website (no command line)

1. Go to [github.com/new](https://github.com/new), name the repo `retail-sales-dashboard` (or similar), set it to **Public**, don't initialize with a README (you already have one)
2. Click **uploading an existing file** on the next screen
3. Drag in every file/folder from this project (`README.md`, `dashboard.html`, `dashboard.js`, `embedded_data.js`, `process.py`, `dashboard_data.json`, `BUILD_IN_POWERBI_TABLEAU.md`, the `data/` folder)
4. Write a commit message like "Initial commit: retail dashboard with RFM segmentation"
5. Click **Commit changes**

## Option B — Command line (git)

```bash
cd retail-dashboard
git init
git add .
git commit -m "Initial commit: retail dashboard with RFM segmentation"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/retail-sales-dashboard.git
git push -u origin main
```

## After it's up

1. **Take a screenshot/GIF** of `dashboard.html` running in your browser, save it to `images/preview.png`, commit it, and add it to the top of the README (see the note in README.md)
2. **Pin the repo** on your GitHub profile: Profile → Customize your pins → select this repo
3. **Enable GitHub Pages** so the dashboard is viewable as a live link, not just a file in a repo:
   - Repo → Settings → Pages → Source: `main` branch, `/ (root)` folder → Save
   - After a minute, your dashboard will be live at `https://YOUR_USERNAME.github.io/retail-sales-dashboard/dashboard.html`
   - Put that link at the very top of your README and in your resume/LinkedIn — this is the single highest-impact thing you can do, since it means people can click and interact without downloading anything
4. If you recreate this in actual Power BI/Tableau (see `BUILD_IN_POWERBI_TABLEAU.md`), publish to Tableau Public and add that link too — having both a code-based and native-tool version shows range
